extern void GetMounts(int gnuwin);
extern char *TranslateFileNameU2D(char *in, int offset);
extern char *TranslateFileNameD2U(char *in, int offset);
